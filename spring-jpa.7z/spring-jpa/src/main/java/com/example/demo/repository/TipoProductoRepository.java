package com.example.demo.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.TipoProducto;

@Repository
public interface TipoProductoRepository extends CrudRepository<TipoProducto, Long> {

	Optional<TipoProducto> findByCodigo(String codigo);
	
	List<TipoProducto> findByDescripcion(String descripcion);
	
}
