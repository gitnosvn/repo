package com.example.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "TIPO_PRODUCTO_TB")
public class TipoProducto {

	@Id
	private Long id;
	
	@Column(name = "V_CODIGO", length = 50, unique = true)
	private String codigo;

	@Column(name = "V_descripcion", length = 50)
	private String descripcion;
}
