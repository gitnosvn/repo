package com.example.demo.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dto.ProductoRequest;
import com.example.demo.entity.Producto;
import com.example.demo.entity.TipoProducto;
import com.example.demo.repository.ProductoRepository;
import com.example.demo.repository.TipoProductoRepository;

@Service
public class ProductoServiceImpl implements ProductoService {
	
	@Autowired
	private ProductoRepository productoRespository;

	@Autowired
	private TipoProductoRepository tipoProductoRepository;

	@Override
	public Iterable<Producto> listado() {
		return productoRespository.findAll();
	}

	@Override
	public List<Producto> pereciblesAntesDe(Date fecha) {
		return productoRespository.findByPerecibleAndFechaExpiracionBefore(true, fecha);
	}

	@Override
	public Producto guardar(ProductoRequest request) throws Exception {
		Producto nuevo = new Producto();
		TipoProducto tipo = tipoProductoRepository.findByCodigo(request.getCodigoTipo())
				.orElseThrow(() -> new Exception("El tipo de producto ingresado no se encuentra en la BD"));

		nuevo.setNombre(request.getNombre());
		nuevo.setPrecio(request.getPrecio());
		nuevo.setTipoProducto(tipo);
		return productoRespository.save(nuevo);
	}

}
