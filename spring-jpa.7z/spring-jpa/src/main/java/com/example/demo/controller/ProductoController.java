package com.example.demo.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.ProductoRequest;
import com.example.demo.entity.Producto;
import com.example.demo.service.ProductoService;

@RestController
public class ProductoController {
	
	@Value("${palabra}")
	String palabra;
	
	@Autowired
	private ProductoService productoService;

	@GetMapping("/listado")
	public Iterable<Producto> listarProductos() {
		return productoService.listado();
	}
	
	@GetMapping("/perecibles")
	public List<Producto> listarProductosPerecibles() {
		return productoService.pereciblesAntesDe(new Date());
	}

	@PostMapping("/guardar")
	public Producto guardar(ProductoRequest request) throws Exception {
		return productoService.guardar(request);
	}
	
	@GetMapping("/palabra")
	public String palabra() {
		return this.palabra;
	}
}
