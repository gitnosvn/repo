package com.example.demo.dto;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProductoRequest {

	private String nombre;

	private BigDecimal precio;

	@JsonProperty("codigo_tipo_producto")
	private String codigoTipo;
}
